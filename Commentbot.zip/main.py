from telethon import TelegramClient, events

api_id = 22597542
api_hash = '692bba01d4d39100bb102cf9fcb3f2e4'
session_name = 'ses'
user_id = 'https://t.me/onenoeee'
chat_id = 1840923250
user_id2 = 'https://t.me/pizdataya_misl'
chat_id2 = 1938408515
client = TelegramClient(session_name, api_id, api_hash)
@client.on(events.NewMessage(chats=chat_id, from_users=user_id))
async def comment(event):
    message = event.message
    await message.reply("Вот это да😨")

@client.on(events.NewMessage(chats=chat_id2, from_users=user_id2))
async def comment2(event):
    message = event.message
    await message.reply("АХУЕТb!!!")

client.start()
client.run_until_disconnected()